<?php $__env->startSection('content'); ?>
				<div class="main-body">
                    <?php echo $__env->make('backend.common.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<div class="inner-body">
						<!--header-->
						<div class="header">
							<div class="row">
								<div class="col-md-12 col-sm-12 col-xs-12">
									<div class="title">
										<!-- <h2>My Tenders</h2> -->
										<p class="navigation">
											<a href="<?php echo e(route('admin.categories')); ?>"><?php echo e(__('Category List')); ?></a>
											<a href="Myuser-details.html"><?php echo e(__('Category Details')); ?></a>
										</p>
									</div>
								</div>
							</div>
						</div><!--END header-->

						<div class="row">
								<div class="col-md-12">
                        		<div class="text-right"><button class="btn btn-theme btn-add-field">Add Field</button></div>
                        	</div>
						</div>

						<!--supplier-details-->
						<div class="supplier-profile-details Myuser-details">
								<div class="row">
									<!--supplier profile-->
									<div class="col-md-4 col-sm-4 col-xs-12">
										<form action="<?php echo e(route('admin.category.update',$data['category']->id)); ?>" method="post" enctype="multipart/form-data">
										<?php echo csrf_field(); ?>
										<?php echo e(method_field('PUT')); ?>

											<div class="profile-details">
												<div class="row">
													<div class="col-md-12">
														<div class="input-details">
															<div class="form-group">
															   <input class="form-control" type="text" placeholder="<?php echo e(__('title in english')); ?>" name="title" value="<?php echo e(old('title') ?? $data['category']->title); ?>" >
																<?php if($errors->has('title')): ?>
																   <span class="text-error"><?php echo e($errors->first('title')); ?></span>
																<?php endif; ?>
															</div>
														</div>
													</div>
												</div>
												<div class="input-details">
													<div class="custom-upload-img">
													
													<label>
														<img onerror="imageUpload(this)" src="<?php echo e($data['category']->image); ?>">
														<input type="file" name="image" accept="image/*">
	                                                	 <?php if($errors->has('image')): ?>
														     <span class="text-error"><?php echo e($errors->first('image')); ?></span>
														 <?php endif; ?>
													</label>
												</div>
												</div>
												<button class="btn-theme"><?php echo e(__('Update')); ?></button>
											</div>
										 </form>
									</div><!--END supplier profile-->
											<!--supplier profile-->
									<div class="col-md-8 col-sm-8 col-xs-12">
										<table class="table">
											<thead>
												<thead>
													<tr>
														<th>Title</th>
														<th>Type</th>
														<th>Defaul</th>
														<th>Required</th>
														<th>Edit/Delete</th>
													</tr>
												</thead>
												<tbody>
													<?php $__empty_1 = true; $__currentLoopData = $data['category']->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
														<tr>
															<td><?php echo e($field->title); ?></td>
															<td><?php echo e($field->type); ?></td>
															<td><?php echo e($field->default ?? '-'); ?></td>
															<td><?php echo e($field->is_required ? 'Yes' : 'No'); ?></td>
															<td><i data-id="<?php echo e($field->id); ?>" class="fa fa-edit btn-edit"></i>&nbsp;<i data-id="<?php echo e($field->id); ?>" class="fa fa-trash btn-dlt"></i></td>
														</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
													<?php endif; ?>
												</tbody>
											</thead>
											
										</table>
									</div><!--END supplier profile-->
								</div>
						</div><!--END supplier-details-->

						<!-- Modal -->
						<div class="modal fade" id="add-field-modal" role="dialog" aria-labelledby="add-field-modal" aria-hidden="true">
						  <div class="modal-dialog" role="document">
						    <div class="modal-content">
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLongTitle">Add field</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						        <form action="<?php echo e(route('admin.create.field')); ?>" method="post" id="create-field-form">
								      <div class="modal-body"> 
								        	<?php echo csrf_field(); ?>
								        	<input type="hidden" name="category_id" value="<?php echo e($data['category']->id); ?>">
								           <div class="form-group">
								           	 <label>Title<span>*</span></label>
								             <input type="text" name="title" class="form-control">
								           </div>
								           <div class="form-group">
								           	 <label>Type<span>*</span></label>
		                                     <select class="form-control" name="type">
		                                     	<option value="text" selected>Text</option>
		                                     	<option value="email">Email</option>
		                                     	<option value="phone">Phone</option>
		                                     	<option value="number">Number</option>
		                                     	<option value="textarea">Textarea</option>
		                                     	<option value="radio">Radio</option>
		                                     	<option value="checkbox">CheckBox</option>
		                                     	<option value="password">Password</option>
		                                     	<option value="select">Select</option>
		                                     	<option value="time">Time</option>
		                                     	<option value="cost">Cost</option>
		                                     	<option value="date">Date</option>
		                                     	<option value="year">Year</option>
		                                     	<option value="file">File</option>
		                                     </select>
								           </div>
								           <div class="form-group">
								           	 <label>Default Value</label>
								             <input type="text" name="default" value="" class="form-control">
								           </div>
								           <div class="form-group">
								           	 <label>Help</label>
								             <input type="text" name="help" value="" class="form-control">
								           </div>
								           <div class="form-group option-input">
								           	 <label>Option</label>
								             <div>
								             	<input type="text" name="option" class="form-control" data-role="tagsinput">
								             </div>
								           </div>
								           <div class="form-group">
								           	<label>
								           	  <input type="checkbox" name="is_required" value="1"> Required
								           	</label>
								           </div>
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-theme">Save</button>
								      </div>
						        </form>
						    </div>
						  </div>
						</div>

						<!-- Modal -->
						<div class="modal fade" id="edit-field-modal" role="dialog" aria-labelledby="add-field-modal" aria-hidden="true">
						  <div class="modal-dialog" role="document">
						    <div class="modal-content">
						      <div class="modal-header">
						        <h5 class="modal-title" id="exampleModalLongTitle">Edit field</h5>
						        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						          <span aria-hidden="true">&times;</span>
						        </button>
						      </div>
						        <form action="<?php echo e(route('admin.update.field')); ?>" method="post" id="edit-field-form">
						        	<?php echo csrf_field(); ?>
						        	<?php echo e(method_field('PUT')); ?>

						        	<input type="hidden" name="id" value="">
								      <div class="modal-body"> 
								        	<?php echo csrf_field(); ?>
								        	<input type="hidden" name="category_id" value="<?php echo e($data['category']->id); ?>">
								           <div class="form-group">
								           	 <label>Title<span>*</span></label>
								             <input type="text" name="title" class="form-control">
								           </div>
								           <div class="form-group">
								           	 <label>Type<span>*</span></label>
		                                     <select class="form-control" name="type">
		                                     	<option value="text">Text</option>
		                                     	<option value="email">Email</option>
		                                     	<option value="phone">Phone</option>
		                                     	<option value="number">Number</option>
		                                     	<option value="textarea">Textarea</option>
		                                     	<option value="radio">Radio</option>
		                                     	<option value="checkbox">CheckBox</option>
		                                     	<option value="password">Password</option>
		                                     	<option value="select">Select</option>
		                                     	<option value="time">Time</option>
		                                     	<option value="cost">Cost</option>
		                                     	<option value="date">Date</option>
		                                     	<option value="year">Year</option>
		                                     	<option value="file">File</option>
		                                     </select>
								           </div>
								           <div class="form-group">
								           	 <label>Default Value</label>
								             <input type="text" name="default" value="" class="form-control">
								           </div>
								          <div class="form-group">
								           	 <label>Help</label>
								             <input type="text" name="help" value="" class="form-control">
								           </div>
								           <div class="form-group option-input">
								           	 <label>Option</label>
												<input type="text" name="option" data-role="tagsinput">
								           </div>
								           <div class="form-group">
								           	<label>
								           	  <input type="checkbox" name="is_required" value="1"> Required
								           	</label>
								           </div>
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-theme">Update</button>
								      </div>
						        </form>
						    </div>
						  </div>
						</div>

					</div>
				</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
 <style type="text/css">
 </style>
 <link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend/css/tag.input.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
 <script type="text/javascript" src="<?php echo e(asset('public/backend/js/tag.input.min.js')); ?>"></script>
 <script type="text/javascript">

 	 $('#add-field-modal input[name="option"]').tagsInput();

 	 $('.option-input').hide();

 	 $('select[name="type"]').on('change',function(e){
 	 	 let value = e.target.value;
 	 	     if(value == 'select'){
 	 	     	$('.option-input').show();
 	 	     }else{
 	 	     	$('.option-input').hide();
 	 	     }
 	 });

 	// Get Fields
 	  let getFields = function (){
					$.ajax(
					{
						"headers":{
						'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
					},
						'type':'get',
						'url' : "<?php echo e(route('ajax.fields',$data['category']->id)); ?>",
					beforeSend: function() {

					},
					'success' : function(response){
						console.log(response);
						let html = '';
						response.data.map(function(field,key){
							html += '<tr>';
							html += `<td>${field.title}</td>`;
							html += `<td>${field.type}</td>`;
							html += `<td>${field.default != null && field.default != '' ? field.default : ''}</td>`;
							html += `<td>${field.is_required == '1' ? 'yes' : 'no'}</td>`;
							html += `<td><i data-id="${field.id}" class="fa fa-edit btn-edit"></i>&nbsp;<i data-id="${field.id}" class="fa fa-trash btn-dlt"></i></td>`;
							html += '<tr>';
						});
              	        $('table tbody').html(html);
					},
  					'error' : function(error){
					},
					complete: function() {
					},
					});
 	  }

 	  $('input[name="option"]').on('click',function(e){
 	  	 e.preventDefault();
         $('input[name="option"]').tagsInput({width:'auto'});
 	  });

 	   //Image Preview
      $('input[type="file"]').on('change',function(event){
      // event.preventDefault();
       tmppath = URL.createObjectURL(event.target.files[0]);
      });

         $('body').on('click','.btn-dlt',function(e){
		  	  let id  = $(this).attr('data-id');
	          let url = "<?php echo e(route('admin.delete.field')); ?>" + '/' + id;
			  swal({
			  title: "<?php echo e(__('Are you sure?')); ?>",
			  text: "<?php echo e(__('Once deleted, you will not be able to recover this field!')); ?>",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			 })
			 .then((willDelete) => {
				if(!willDelete){
					return false;
				}
					$.ajax({
						"headers":{
						'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
					},
						'type':'DELETE',
						'url' : url,
					beforeSend: function() {
					},
					'success' : function(response){
						if(response.status == 'success'){
							swal("Success!",response.message, "success");
   					        getFields();
						}
						if(response.status == 'failed'){
							swal("Failed!",response.message, "error");
						}
					},
					'error' : function(error){
					},
					complete: function() {
					},
					});
			 });
	     });

	     $('.btn-add-field').on('click',function(e){
	     	$('#create-field-form input[type="text"],#create-field-form select').val('');
	     	$('#add-field-modal').modal('show');
	     });
         
         $('#create-field-form').on('submit',function(e){
         	e.preventDefault();
			let form  = $(this);
		    let data = form.serialize();
			$.ajax({
				"headers":{
				'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
			},
				'type':'POST',
				'url' : form.attr('action'),
				'data' : data,
			beforeSend: function() {

			},
			'success' : function(response){
				form.find('.text-error').remove();
				console.log(response);
				if(response.status == 'success'){
				      swal("Success!",response.message, "success");
	  				  form.find('input[type="text"],select').val('');
	  				  $('#add-field-modal').modal('hide');
                      getFields();
	  			}
				if(response.status == 'failed'){
				     swal("Failed!",response.message, "error");
				}
				if(response.status == 'error'){
					$.each(response.errors, function (key, val) {
					form.find('[name='+key+']').after('<span class="text-error">'+val+'</span>');
					});
				}
			},
			'error' : function(error){
				console.log(error);
			},
			complete: function() {

			},
			});

         });

			$('body').on('click','.btn-edit',function(e){
				e.preventDefault();
				let id = $(this).attr('data-id');
				$.ajax(
					{
						"headers":{
						'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
					},
						'type':'get',
						'url' : "<?php echo e(route('admin.ajax.field')); ?>" +'/'+ id,
					beforeSend: function() {

					},
					'success' : function(response){
					    if(response.status=='success'){
					    	$('#edit-field-modal input[name="id"]').val(response.data.id);
					    	$('#edit-field-modal input[name="title"]').val(response.data.title);
					    	$('#edit-field-modal select[name="type"]').val(response.data.type);
					    	$('#edit-field-modal input[name="default"]').val(response.data.default);
					    	$('#edit-field-modal input[name="help"]').val(response.data.help);
					    	$('#edit-field-modal input[name="is_required"]').prop('checked',response.data.help);
					    	if(response.data.type == 'select'){
					    		 $('#edit-field-modal .option-input').show();
				    	    	 $('#edit-field-modal input[name="option"]').val(response.data.field_options);
				    	    	 $('#edit-field-modal input[name="option"]').tagsInput('refresh');
					    	}
					    }
					},
  					'error' : function(error){
					},
					complete: function() {
					},
					});
				$('#edit-field-modal').modal('show');
			});

			$('#edit-field-form').on('submit',function(e){
         	e.preventDefault();
			let form  = $(this);
		    let data = form.serialize();
			$.ajax({
				"headers":{
				'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
			},
				'type':'PUT',
				'url' : form.attr('action'),
				'data' : data,
			beforeSend: function() {

			},
			'success' : function(response){
				form.find('.text-error').remove();
				if(response.status == 'success'){
				      swal("Success!",response.message, "success");
	  				  form.find('input[type="text"],select').val('');
	  				  $('#edit-field-modal').modal('hide');
                      getFields();
	  			}
				if(response.status == 'failed'){
				     swal("Failed!",response.message, "error");
				}
				if(response.status == 'error'){
					$.each(response.errors, function (key, val) {
					form.find('[name='+key+']').after('<span class="text-error">'+val+'</span>');
					});
				}
			},
			'error' : function(error){
				console.log(error);
			},
			complete: function() {

			},
			});

         });
 </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.layouts.loggedInApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>