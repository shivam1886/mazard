<?php $__env->startSection('content'); ?>
    <div class="main-body">
           <?php echo $__env->make('backend.common.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <!-----START searching box--------->
          <section class="searching-filter">
            <form method="GET">
              <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="input">
                        <input type="text" placeholder="<?php echo e(__('Search by city , division & local area')); ?>" name="search" value="<?php echo e(Request::get('search')); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="filter-btn">
                    <a class="button" href="<?php echo e(route('admin.cities')); ?>"><?php echo e(__('Clear')); ?></a>
                    <button class="button" type="submit"><?php echo e(__('Submit')); ?></button>
                  </div>
                </div>
              </div>
            </form>
          </section>
          <!-----END searching box--------->

          <div class="inner-body">
            <!--header-->
            <div class="header">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="title">
                    <h2><?php echo e(__('City Or Division')); ?> (<?php echo e(count($data['cities'])); ?>)</h2>
                    <a style="float: right;" class="btn-theme" href="<?php echo e(route('admin.city.add')); ?>"><?php echo e(__('Add City')); ?></a>
                  </div>
                </div>
              </div>
            </div><!--END header-->

            <!--my tenders-->
            <div class="supplier-request">
              <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $data['cities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <!--single-s-request-->
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="single-s-request">
                      <div class="img-text clearfix">
                        <div class="txt">
                          <h2><?php echo e($city->title); ?> (<?php echo e($city->title_bn); ?>)</h2>
                          <p><b><?php echo e(__('Local Area')); ?> :</b> <?php echo e(__('Not availabe')); ?></p>
                        </div>
                      </div>
                      <div class="buttons txt">
                      <a href="<?php echo e(route('admin.city.edit',$city->id)); ?>"><?php echo e(__('Details')); ?></a>
                      </div>
                    </div>
                  </div><!--END single-s-request-->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
              </div>
            </div><!--END my tenders-->

          </div>  
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.loggedInApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>