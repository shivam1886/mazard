<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
	<meta name="keywords" content="mazard">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('public/backend/images/favicon-icon.png')); ?>">
	<!--css-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/css/bootstrap.min.css">
	<!--font awesome 4-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/fonts/fontawesome/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public')); ?>/css/app.css">
	<style type="text/css">
		body{
			background: #000;
		}
		input, textarea {
		  color:#fff !important;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #14181e !important;
		  box-sizing: border-box;
		  background-color: #090e14 !important;
		}

		select {
		  padding: 12px 20px;
		  margin: 8px 0;
		  color:#fff !important;
		  display: inline-block;
		  border: 1px solid #14181e !important;
		  box-sizing: border-box;
		  background-color: #01385f !important;
		}

		input[type=submit] {
		  width: 100%;
		  background-color: #01385f !important;
		  color: white;
		  padding: 14px 20px;
		  margin: 8px 0;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		}
	</style>
</head>
<body>

  <div class="wrapper">
  	 <form class="form" action="<?php echo e(url('api/submit/form')); ?>" method="get">
  	 	<input type="hidden" name="user_id" value="<?php echo e(Request::get('user_id')); ?>">
  	 	<input type="hidden" name="category_id" value="<?php echo e(Request::get('category_id')); ?>">

			  	 	<div class="form-group">
			  	 		<input type="title" name="title" placeholder="title" value="<?php echo e(old('title')); ?>" class="form-control" autocomplete="off">
			  	 		<?php if($errors->has('title')): ?> 
						    <div class="text-error"><?php echo e($errors->first('title')); ?></div>
						<?php endif; ?>
			  	 	</div>
			  	 	
			  	 	<div class="form-group">
                       <textarea name="description" placeholder="description" class="form-control"><?php echo e(old('description')); ?></textarea>
   			  	 	   <?php if($errors->has('description')): ?>
 						   <span class="text-error"><?php echo e($errors->first('description')); ?></span>
						<?php endif; ?>
			  	 	</div>
			  	 	
			  	 	<div class="form-group">
			  	 		<input type="number" name="price" placeholder="price" value="<?php echo e(old('price')); ?>" class="form-control" autocomplete="off">
			  	 	  	<?php if($errors->has('price')): ?>
 						   <span class="text-error"><?php echo e($errors->first('price')); ?></span>
						<?php endif; ?>
			  	 	</div>

  	 	<?php $__empty_1 = true; $__currentLoopData = $data['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			  <?php switch($field->type):
		       case ('text'): ?>
			  	 	<div class="form-group">
			  	 		<input type="text" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>"  class="form-control" value="<?php echo e(old($field->input_name)); ?>" autocomplete="off">
			  	 		<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
						<?php endif; ?>
			  	 	</div>
		        <?php break; ?>

		        <?php case ('email'): ?>
					<div class="form-group">
					     <input type="email" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>"  class="form-control" value="<?php echo e(old($field->input_name)); ?>" autocomplete="off">
					     <?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
						 <?php endif; ?>
					</div>
				<?php break; ?>
			    <?php case ('phone'): ?>
					<div class="form-group">
					<input type="text" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>"  class="form-control" value="<?php echo e(old($field->input_name)); ?>" autocomplete="off">
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>;
				<?php case ('number'): ?>
					<div class="form-group">
					<input type="number" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>" value="<?php echo e(old($field->input_name)); ?>"  class="form-control" autocomplete="off">
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>;
				<?php case ('cost'): ?>
					<div class="form-group">
					<input type="number" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>" value="<?php echo e(old($field->input_name)); ?>" class="form-control" autocomplete="off">
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>;
				<?php case ('time'): ?>
					<div class="form-group">
					<input type="time" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>" value="<?php echo e(old($field->input_name)); ?>"  class="form-control" value="<?php echo e(old($field->input_name)); ?>" autocomplete="off">
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>;
				<?php case ('date'): ?>
					<div class="form-group">
					<input type="date" name="<?php echo e($field->input_name); ?>" placeholder="<?php echo e($field->title); ?>"  class="form-control" value="<?php echo e(old($field->input_name)); ?>" autocomplete="off">
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>;
				<?php case ('year'): ?>
					<div class="form-group">
					<input type="year" name="<?php echo e($field->input_name); ?>" value="<?php echo e(old($field->input_name)); ?>" placeholder="<?php echo e($field->title); ?>"  class="form-control" autocomplete="off">
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>;
				<?php case ('select'): ?>
					<div class="form-group">
					<select name="<?php echo e($field->input_name); ?>" class="form-control">
						<option ><?php echo e($field->input_name); ?></option>
						<?php $__empty_2 = true; $__currentLoopData = unserialize($field->field_options); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
						 <option <?php if(old($field->input_name) == $option): ?> selected <?php endif; ?> value="<?php echo e($option); ?>"><?php echo e($option); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
						<?php endif; ?>
					</select>
					<?php if($errors->has($field->input_name)): ?> 
						    <div class="text-error"><?php echo e($errors->first($field->input_name)); ?></div>
					<?php endif; ?>
					</div>
				<?php break; ?>
			<?php endswitch; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>
		<input type="submit" value="Add">
  	 </form>
  </div>  

</body>
 <!--script-->
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/sweetalert.min.js"></script>
<style type="text/css">
	form{
		padding: 10px;
	}
</style>
</html>