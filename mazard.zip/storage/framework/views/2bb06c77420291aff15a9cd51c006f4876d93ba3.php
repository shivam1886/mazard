<?php $__env->startSection('content'); ?>
    <div class="main-body">
           <?php echo $__env->make('backend.common.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <!-----START searching box--------->
          <section class="searching-filter">
            <form method="GET">
              <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="input">
                        <input type="text" placeholder="Search by key" name="key" value="<?php echo e(Request::get('key')); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="filter-btn">
                    <a class="button" href="<?php echo e(route('admin.config')); ?>">Clear</a>
                    <button class="button" type="submit">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </section>
          <!-----END searching box--------->

          <div class="inner-body">
            <!--header-->
            <div class="header">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="title">
                  </div>
                </div>
              </div>
            </div><!--END header-->

            <!--my tenders-->
            <div class="supplier-request">
                <table class="table">
                  <tr>
                     <thead>
                        <th>Sr.</th>
                        <th>Config Key</th>
                        <th>Value</th>
                        <th>Action</th>
                     </thead>
                     <tbody>
                        <?php $i = 1 ?>
                        <?php $__currentLoopData = $data['config']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                             <td><?php echo e($i++); ?></td>
                             <td><?php echo e($config->key); ?></td>
                             <td><?php echo e($config->value); ?></td>
                             <td><a href="<?php echo e(route('admin.get.config',$config->id)); ?>" class="btn primary">Edit</a></td>
                           </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                  </tr>
                </table>
            </div><!--END my tenders-->

          </div>  
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.loggedInApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>