<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
	<meta name="keywords" content="cleaning, home">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('public/backend/images/favicon-icon.png')); ?>">
	<!--css-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/css/style.css"><?php echo e(asset('public/backend')); ?>/
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/css/responsive.css">
	<!--font awesome 4-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/fonts/fontawesome/css/all.min.css">
	<!--data table-->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('public/backend')); ?>/css/dataTables.bootstrap.css">
	<?php echo $__env->yieldPushContent('css'); ?>
	<script type="text/javascript">

	 function profileImgError(image) {
		image.onerror = "";
		image.src = "<?php echo e(asset('public/backend/images/user-default-image.png')); ?>";
		return true;
	 }

	 function imgError(image) {
		image.onerror = "";
		image.src = "<?php echo e(asset('public/backend/images/image-not-found.jpg')); ?>";
		return true;
	 }

	 function imageUpload(image) {
		image.onerror = "";
		image.src = "<?php echo e(asset('public/backend/images/upload-image.png')); ?>";
		return true;
 	 } 
	
</script>
</head>
<body onload="loaderfun()">
	<div id="loader-wrapper">
		<div id="loader">
			<div class="svg-wrapper">
				<img src="<?php echo e(asset('public/backend')); ?>/images/loader1.gif">
			</div>
		</div>
	</div>
	<main class="clearfix">
		<div class="noty-overlay"></div>
		<!--left block-->
		<div class="left-block">
			<button class="close-menu">
				<i class="fa fa-times"></i>
			</button>
			<div class="left-block-body">
				<nav>
					<div class="nav-logo">
						<a href="<?php echo e(route('admin.home')); ?>">
							<img src="<?php echo e(asset('public/backend')); ?>/images/nav-logo2.png" class="logo">
							<img src="<?php echo e(asset('public/backend')); ?>/images/logo-icon.png" class="logo-icon">
						</a>
					</div>

					<div class="navlink">
						<ul>
							<li>
									<a href="<?php echo e(route('admin.home')); ?>"><i class="fas fa-chart-line"></i><span><?php echo e(__('Dashboard')); ?></span></a>
							</li>
							<li><a href="<?php echo e(route('admin.users')); ?>"><i class="fa fa-users"></i> <span><?php echo e(__('Users')); ?></span></a></li>
							<li><a href="<?php echo e(route('admin.products')); ?>"><i class="fa fa-list-alt"></i> <span><?php echo e(__('Ads')); ?></span></a></li>
							<li><a href="<?php echo e(route('admin.categories')); ?>"><i class="fa fa-layer-group"></i> <span><?php echo e(__('Categories')); ?></span></a></li>
							<li><a href="<?php echo e(route('admin.cities')); ?>"><i class="fa fa-layer-group"></i> <span><?php echo e(__('Cities or Divisions')); ?></span></a></li>
							<li><a href="<?php echo e(route('admin.config')); ?>"><i class="fa fa-layer-group"></i> <span><?php echo e(__('Config')); ?></span></a></li>
							<li><a href="<?php echo e(route('admin.logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fas fa-sign-in-alt"></i>  <?php echo e(__('Logout')); ?></a>
							<form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" style="display: none;">
							<?php echo e(csrf_field()); ?>

							</form></li>

						</ul>
					</div>
				</nav>
			</div>
		</div>
		<!--left block end-->

		<!--right-block-->
		<div class="right-block">
			<div class="Navoverlay"></div>
			<div class="right-block-body">
				<div class="top-nav">
					<div class="nav-item clearfix">
						<div class="row">
							<div class="col-md-4 col-sm-4 col-xs-3">
								<div class="left-item">
									<button class="toggle-btn"><i class="fa fa-bars"></i></button>
								</div>
							</div>
							<div class="col-md-4 col-sm-4 d-none-m">
								 <div class="title">Dashboard</div>
							</div>
							<div class="col-md-4 col-sm-4 col-xs-9 text-right">
								<div class="right-item">
									<div class="user-profile">
										   <a href="<?php echo e(route('admin.profile')); ?>">
											<img onerror="profileImgError(this)" src="<?php echo e(auth::user()->profile_image); ?>" alt="profile" class="img-responsive">
										</a>
										<span>
											<h2><?php echo e(auth::user()->name); ?></h2>
										</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!------right block body-->
                <?php $__env->startSection('content'); ?><?php echo $__env->yieldSection(); ?>
			</div>
		</div>
		<!--right-block end-->

	</main>
<!--script-->
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/bootstrap.min.js"></script>
<!--data table-->
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/dataTables.bootstrap.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/custom.js"></script>
<script type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/js/sweetalert.min.js"></script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>