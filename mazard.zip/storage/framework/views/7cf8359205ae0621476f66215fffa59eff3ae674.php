	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend')); ?>/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/public/frontend')); ?>/css/style.css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend')); ?>/css/responsive.css">
	<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/css/jquery.mCustomScrollbar.css" />
	<!--font awesome 4-->
	<link rel="stylesheet" type="<?php echo e(asset('frontend')); ?>/text/css" href="fonts/fontawesome/css/all.min.css">
	<link rel="shortcut icon" href="<?php echo e(asset('frontend')); ?>/images/favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/css/viewer.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/css/viewer_main.css">
    <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/css/toastr.min.css">
    <script type="text/javascript">
    	 function profileImgError(image) {
			image.onerror = "";
			image.src = "<?php echo e(asset('public/backend/images/user-default-image.png')); ?>";
			return true;
		 }

		 function imgError(image) {
			image.onerror = "";
			image.src = "<?php echo e(asset('public/backend/images/image-not-found.jpg')); ?>";
			return true;
		 }
    </script>

    