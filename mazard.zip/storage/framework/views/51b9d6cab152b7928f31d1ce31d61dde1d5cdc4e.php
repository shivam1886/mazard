<?php $__env->startSection('content'); ?>
				<div class="main-body">
                    <?php echo $__env->make('backend.common.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<div class="inner-body">
						<!--header-->
						<div class="header">
							<div class="row">
								<div class="col-md-12 col-sm-12 col-xs-12">
									<div class="title">
										<!-- <h2>My Tenders</h2> -->
										<p class="navigation">
											<a href="<?php echo e(route('admin.categories')); ?>"><?php echo e(__('Category List')); ?></a>
											<a href="Myuser-details.html"><?php echo e(__('Add Category')); ?></a>
										</p>
									</div>
								</div>
							</div>
						</div><!--END header-->
                        <div class="row">
                        	<div class="col-md-4">
                        	  						<!--supplier-details-->
						<div class="supplier-profile-details Myuser-details">
							<form action="<?php echo e(route('admin.store.category')); ?>" method="post" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<div class="row">
									<!--supplier profile-->
									<div class="col-md-12 col-sm-12 col-xs-12">
										<div class="profile-details">
											<div class="row">
												<div class="col-md-12">
													<div class="input-details">
														<div class="form-group">
														   <input class="form-control" type="text" placeholder="<?php echo e(__('title')); ?>" name="title" value="<?php echo e(old('title')); ?>" >
															<?php if($errors->has('title')): ?>
															   <span class="text-error"><?php echo e($errors->first('title')); ?></span>
															<?php endif; ?>
														</div>
													</div>
												</div>
											</div>
											<div class="input-details">
												<div class="custom-upload-img">
													
													<label>
														<img onerror="profileImgError(this)" src="<?php echo e(asset('backend/images/upload-image.png')); ?>">
														<input type="file" name="image" accept="image/*">
	                                                	 <?php if($errors->has('image')): ?>
														     <span class="text-error"><?php echo e($errors->first('image')); ?></span>
														 <?php endif; ?>
													</label>
												</div>
											</div>
											<button class="btn-theme"><?php echo e(__('Add')); ?></button>
										</div>
									</div><!--END supplier profile-->
								</div>
							</form>
						</div><!--END supplier-details-->	
                        	</div>
                        	<div class="col-md-8">
                        		
                        	</div>
                        </div>
					</div>
				</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
 <style type="text/css">
 </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
 <script type="text/javascript">
 	   //Image Preview
      $('input[type="file"]').on('change',function(event){
      // event.preventDefault();
       tmppath = URL.createObjectURL(event.target.files[0]);
       $('.custom-upload-img img').attr('src',tmppath);
      });
 </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.layouts.loggedInApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>