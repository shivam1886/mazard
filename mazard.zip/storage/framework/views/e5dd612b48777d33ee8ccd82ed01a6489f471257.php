<?php $__env->startSection('content'); ?>
				<div class="main-body">
                    <?php echo $__env->make('backend.common.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<div class="inner-body">
						<!--header-->
						<div class="header">
							<div class="row">
								<div class="col-md-12 col-sm-12 col-xs-12">
									<div class="title">
										<!-- <h2>My Tenders</h2> -->
										<p class="navigation">
											<a href="<?php echo e(route('admin.cities')); ?>"><?php echo e(__('City List')); ?></a>
											<a href="javascript:void(0)"><?php echo e(__('Update City')); ?></a>
											<a href="javascript:void(0)"><?php echo e($data['city']->title); ?> (<?php echo e($data['city']->title_bn); ?>) </a>
										</p>
									</div>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-12">
								</div>
							</div>
						</div><!--END header-->

						<!--supplier-details-->
						<div class="supplier-profile-details Myuser-details">
							<form action="<?php echo e(route('admin.city.update',$data['city']->id)); ?>" method="post">
								<?php echo csrf_field(); ?>
								<?php echo e(method_field('PUT')); ?>

								<div class="row">
									<!--supplier profile-->
									<div class="col-md-4 col-sm-4 col-xs-12">
										<div class="profile-details">
											<div class="row">
												<div class="col-md-12">
													<div class="input-details">
														<div class="form-group">
                                                            <select class="form-control" name="type">
                                                            	<option <?php if(old('type') == 'city'): ?> selected <?php else: ?> <?php if($data['city']->type == 'city'): ?> selected <?php endif; ?> <?php endif; ?> value="city"><?php echo e(__('City')); ?></option>
                                                            	<option <?php if(old('type') == 'division'): ?> selected <?php else: ?> <?php if($data['city']->type == 'division'): ?> selected <?php endif; ?> <?php endif; ?> value="division"><?php echo e(__('Division')); ?></option>
                                                            </select>
															<?php if($errors->has('type')): ?>
															   <span class="text-error"><?php echo e($errors->first('type')); ?></span>
															<?php endif; ?>
														</div>
													</div>
												</div>
												<div class="col-md-12">
													<div class="input-details">
														<div class="form-group">
														   <input class="form-control" type="text" placeholder="<?php echo e(__('title in english')); ?>" name="english_title" value="<?php echo e(old('title_en') ?? $data['city']->title); ?>" >
															<?php if($errors->has('english_title')): ?>
															   <span class="text-error"><?php echo e($errors->first('english_title')); ?></span>
															<?php endif; ?>
														</div>
													</div>
												</div>
												<div class="col-md-12">
													<div class="input-details">
														<div class="form-group">
															<input class="form-control" type="text" placeholder="<?php echo e(__('title in bangla')); ?>" name="bangla_title" value="<?php echo e(old('title_bn') ?? $data['city']->title_bn); ?>" >
															<?php if($errors->has('bangla_title')): ?>
															   <span class="text-error"><?php echo e($errors->first('bangla_title')); ?></span>
															<?php endif; ?>
														</div>
													</div>
												</div>
											</div>
											<button class="btn-theme"><?php echo e(__('Update')); ?></button>
										</div>
									</div><!--END supplier profile-->
								</form>
												<!--supplier profile-->
									<div class="col-md-6 col-sm-6 col-xs-12">
										<div class="city-area-list">
												<?php $__empty_1 = true; $__currentLoopData = $data['city']->areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
												    <?php if(!is_null($area->delete_at)): ?>
												      <?php continue ?>
												    <?php endif; ?>
													<form action="<?php echo e(route('admin.area.update')); ?>" method="POST" class="update-area-form">
														 <div class="profile-details">
															<label class="btn-dlt-wrapper">
			    												<i class="fa fa-trash btn-dlt" data-city-id="<?php echo e($data['city']->id); ?>" data-url="<?php echo e(route('admin.area.remove',$area->id)); ?>"></i>
															</label>
															<?php echo csrf_field(); ?>
															<?php echo e(method_field('PUT')); ?>

															<input type="hidden" name="area_id" value="<?php echo e($area->id); ?>">
															<div class="row">
																<div class="col-md-6">
																	<div class="input-details">
																		<div class="form-group">
																		   <input class="form-control" type="text" placeholder="<?php echo e(__('title in english')); ?>" name="english_title" value="<?php echo e($area->title); ?>" readonly>
																		</div>
																	</div>
																</div>
																<div class="col-md-6">
																	<div class="input-details">
																		<div class="form-group">
																			<input class="form-control" type="text" placeholder="<?php echo e(__('title in bangla')); ?>" name="bangla_title" value="<?php echo e($area->title_bn); ?>" readonly>
																		</div>
																	</div>
																</div>
															</div>
															<div class="btn-wrapper">
																<button class="btn-theme btn-edit"><?php echo e(__('Edit')); ?></button>
	           												    <button style="display: none;" class="btn-theme btn-reset"><?php echo e(__('Reset')); ?></button>
																<input style="display: none;"type="submit" class="btn-theme btn-update" value="<?php echo e(__('Update')); ?>">
															</div>
													     </div>
													</form>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
												<?php endif; ?>
										</div>
											<form action="<?php echo e(route('admin.area.add')); ?>" method="POST" class="add-area-form">
												<div class="profile-details">
														<?php echo csrf_field(); ?>
														<input type="hidden" name="city_id" value="<?php echo e($data['city']->id); ?>">
														<div class="row">
															<div class="col-md-6">
																<div class="input-details">
																	<div class="form-group">
																	   <input class="form-control" type="text" placeholder="<?php echo e(__('title in english')); ?>" name="english_title" value="" >
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="input-details">
																	<div class="form-group">
																		<input class="form-control" type="text" placeholder="<?php echo e(__('title in bangla')); ?>" name="bangla_title" value="" >
																	</div>
																</div>
															</div>
														</div>
														<input type="submit" class="btn-theme" value="<?php echo e(__('Add')); ?>">
												</div>
											</form>
									</div><!--END supplier profile-->
								</div>
							</form>
						</div><!--END supplier-details-->
					</div>
				</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
 <style type="text/css">
 </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('js'); ?>
 <script type="text/javascript">

     // Get Subcity
 	  let getCityArea = function (){
					$.ajax(
					{
						"headers":{
						'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
					},
						'type':'get',
						'url' : "<?php echo e(route('admin.area.list',$data['city']->id)); ?>",
					beforeSend: function() {

					},
					'success' : function(response){
              	        $('.city-area-list').html(response);
					},
  					'error' : function(error){
					},
					complete: function() {
					},
					});
 	  }

 	   //Image Preview
      $('input[type="file"]').on('change',function(event){
      // event.preventDefault();
       tmppath = URL.createObjectURL(event.target.files[0]);
      });
      $('select[name="city"]').on('change',function(e){
      	  if(e.target.value != ''){ $('input[type="file"]').parents('.input-details').hide(); }else{ $('input[type="file"]').parents('.input-details').show();;}
      	   
      });

       $('body').on('submit','.add-area-form',function(e){
	  	e.preventDefault();
	  	return false;
	    var click = $(this);
		let form  = $(this);
	    let data = form.serialize();
		$.ajax({
			"headers":{
			'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
		},
			'type':'POST',
			'url' : form.attr('action'),
			'data' : data,
		beforeSend: function() {

		},
		'success' : function(response){
				click.find('.text-error').remove();
			if(response.status == 'success'){
			      swal("Success!",response.message, "success");
  				  click.find('input[type="text"]').val('');
			      getCityArea();
			}
			if(response.status == 'failed'){
			     swal("Failed!",response.message, "error");
			}
			if(response.status == 'error'){
				$.each(response.errors, function (key, val) {
				click.find('[name='+key+']').after('<span class="text-error">'+val+'</span>');
				});
			}
		},
		'error' : function(error){
			console.log(error);
		},
		complete: function() {

		},
		});
	  });

       $('body').on('submit','.update-area-form',function(e){
	  	e.preventDefault();
	  	console.log('Hello');
	  	return false;
	    var click = $(this);
		let form  = $(this);
	    let data = form.serialize();
		$.ajax({
			"headers":{
			'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
		},
			'type':'PUT',
			'url' : form.attr('action'),
			'data' : data,
		beforeSend: function() {

		},
		'success' : function(response){
				click.find('span').remove();
				click.find('input[type="text"]').val('');
			if(response.status == 'success'){
			      swal("Success!",response.message, "success");
			      getCityArea();
			}
			if(response.status == 'failed'){
			     swal("Failed!",response.message, "error");
			}
			if(response.status == 'error'){
				$.each(response.errors, function (key, val) {
				click.find('[name='+key+']').after('<span class="text-error">'+val+'</span>');
				});
			}
		},
		'error' : function(error){
			console.log(error);
		},
		complete: function() {

		},
		});
	  });

       $('body').on('click','.btn-reset',function(e){
         	 e.preventDefault();
         	 let form = $(this).parents('.update-area-form');             
                 form[0].reset();
       });

       $('body').on('click','.btn-edit',function(e){
       	  e.preventDefault();
       	  $(this).hide();
       	  let form = $(this).parents('.update-area-form');
       	      form.find('input[type="text"]').removeAttr('readonly');
       	      form.find('.btn-update').show();
       	      form.find('.btn-reset').show();
       });

         $('body').on('click','.btn-dlt',function(e){
		  	  var url = $(this).attr('data-url');
	          var parentCategoryId = $(this).attr('data-city-id');
	          var data = { city_id : parentCategoryId };
			  swal({
			  title: "<?php echo e(__('Are you sure?')); ?>",
			  text: "<?php echo e(__('Once deleted, you will not be able to recover this city area!')); ?>",
			  icon: "warning",
			  buttons: true,
			  dangerMode: true,
			 })
			 .then((willDelete) => {
				if(!willDelete){
					return false;
				}
					$.ajax({
						"headers":{
						'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
					},
						'type':'DELETE',
						'url' : url,
						'data' : data,
					beforeSend: function() {
					},
					'success' : function(response){
						if(response.status == 'success'){
							swal("Success!",response.message, "success");
   					        getCityArea();
						}
						if(response.status == 'failed'){
							swal("Failed!",response.message, "error");
						}
					},
					'error' : function(error){
					},
					complete: function() {
					},
					});
			 });
	     });

 </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.layouts.loggedInApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>