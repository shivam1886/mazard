<?php $__env->startSection('content'); ?>
    <div class="main-body">
           <?php echo $__env->make('backend.common.alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
           <!-----START searching box--------->
          <section class="searching-filter">
            <form method="GET">
              <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="input">
                        <input type="text" placeholder="Search by category & subcategory name" name="search" value="<?php echo e(Request::get('search')); ?>">
                      </div>
                    </div>
                  </div>
                </div>
                
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="filter-btn">
                    <a class="button" href="<?php echo e(route('admin.categories')); ?>">Clear</a>
                    <button class="button" type="submit">Submit</button>
                  </div>
                </div>
              </div>
            </form>
          </section>
          <!-----END searching box--------->

          <div class="inner-body">
            <!--header-->
            <div class="header">
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="title">
                    <h2>Category List (<?php echo e(count($data['categories'])); ?>)</h2>
                    <a style="float: right;" class="btn-theme" href="<?php echo e(route('admin.add.category')); ?>">Add Category</a>
                  </div>
                </div>
              </div>
            </div><!--END header-->

            <!--my tenders-->
            <div class="supplier-request">
              <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <!--single-s-request-->
                  <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="single-s-request">
                      <div class="img-text clearfix">
                        <div class="img">
                          <img src="<?php echo e($category->image); ?>" onerror="imgError(this)">
                        </div>
                        <div class="txt">
                          <h2><?php echo e($category->title); ?></h2>
                           <p><i class="fas fa-layer-group"></i>
                             <?php $__empty_2 = true; $__currentLoopData = $category->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span><?php echo e($sub_category->title); ?>,</span>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                 <span>Sub category not available</span>
                             <?php endif; ?>
                           </p>
                        </div>
                      </div>
                      <div class="buttons txt">
                      <a href="<?php echo e(route('admin.category.details',$category->id)); ?>">Details</a>
                      </div>
                    </div>
                  </div><!--END single-s-request-->
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
              </div>
            </div><!--END my tenders-->

          </div>  
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.loggedInApp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>