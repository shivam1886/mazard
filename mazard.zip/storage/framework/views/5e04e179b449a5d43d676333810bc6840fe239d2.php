	<!--footer-->
	<footer>
		<div class="footer">
			<div class="container">
				<div class="row">
	
					<div class="col-md-4 col-sm-6 col-xs-12">
						<div class="single-footer">
							<a href="index.html" class="logo"><img src="<?php echo e(asset('public/frontend')); ?>/images/logo-gray.png"></a>
							<p>What is Lorem Ipsum Lorem Ipsum is simply dummy text of the printing and typesetting industry Lorem Ipsum has been the What is Lorem Ipsum Lorem  </p>
						</div>
					</div>
	
					<div class="col-md-2 col-sm-6 col-xs-12">
						<div class="single-footer">
							<h2>Social</h2>
							<ul>
								<li><a href="javascript:void(0);">Facebook</a></li>
								<li><a href="javascript:void(0);">Youtube</a></li>
								<li><a href="javascript:void(0);">Instagram</a></li>
								<li><a href="javascript:void(0);">Twitter</a></li>
							</ul>
						</div>
					</div>

					<div class="col-md-2 col-sm-6 col-xs-12">
						<div class="single-footer">
							<h2>Learn More</h2>
							<ul>
								<li><a href="javascript:void(0);">How to sell fast</a></li>
								<li><a href="javascript:void(0);">Membership</a></li>
								<li><a href="javascript:void(0);">Banner Advertising</a></li>
								<li><a href="javascript:void(0);">Promote your ad</a></li>
							</ul>
						</div>
					</div>

					<div class="col-md-2 col-sm-6 col-xs-12">
						<div class="single-footer">
							<h2>Help & Support</h2>
							<ul>
								<li><a href="javascript:void(0);">FAQ</a></li>
								<li><a href="javascript:void(0);">Stay safe on BikroyKari.com</a></li>
								<li><a href="javascript:void(0);">Contact us</a></li>
							</ul>
						</div>
					</div>

					<div class="col-md-2 col-sm-6 col-xs-12">
						<div class="single-footer">
							<h2>About us</h2>
							<ul>
								<li><a href="javascript:void(0);">About us</a></li>
								<li><a href="javascript:void(0);">Careers</a></li>
								<li><a href="javascript:void(0);">Terms & Conditions</a></li>
								<li><a href="javascript:void(0);">Privacy Policy</a></li>
								<li><a href="javascript:void(0);">Sitemap</a></li>
							</ul>
						</div>
					</div>
	
				</div>
			</div>
		</div>

		<div class="copyright">
			<p>All Right Reserved Copyright@2020-2022</p>
		</div>
	</footer><!--end-->